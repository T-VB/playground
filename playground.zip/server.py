from flask import Flask, render_template  # Import Flask to allow us to create our app
app = Flask(__name__)

#1) render 3 blue boxes with /play
@app.route('/play')
def play():
    return render_template('index.html',num = 3, color = '#9fc5f8') #num and color here are preset for /play

#1) render x blue boxes, with /play/num
@app.route('/play/<int:num>')
def num(num):
    return render_template('index.html', num = num, color = '#9fc5f8')

#1) render x blue boxes specific color, with /play/num/color
@app.route('/play/<int:num>/<string:color>')
def color_num(num, color):
    return render_template('index.html', num = num, color = color)

if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)